﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
namespace MeatShop
{

    public partial class MainForm : Form
    {

        Databases db = new Databases();
        public MySqlConnection conn;


        public MainForm()
        {
            InitializeComponent();
            conn = db.Connect();
            LoadData();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadData();
            // Add Update button column
            DataGridViewButtonColumn updateButton = new DataGridViewButtonColumn();
            updateButton.Name = "Update";
            updateButton.Text = "Update";
            updateButton.UseColumnTextForButtonValue = true;
            dgcInventory.Columns.Add(updateButton);
            // Add Delete button column
            DataGridViewButtonColumn deleteButton = new DataGridViewButtonColumn();
            deleteButton.Name = "Delete";
            deleteButton.Text = "Delete";
            deleteButton.UseColumnTextForButtonValue = true;
            dgcInventory.Columns.Add(deleteButton);
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void btnADD_Click_1(object sender, EventArgs e)
        {
            Files form2 = new Files(this);
            form2.ShowDialog();
        }

        private void guna2GradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        public void LoadData()
        {
            try
            {

                db.OpenConnection(conn);
                string query = "SELECT * FROM Files";
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgcInventory.DataSource = dt;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void dgcInventory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (dgcInventory.Columns[e.ColumnIndex].Name == "Update")
                {
                    // Open Files form in update mode with the selected row
                    Files form = new Files(this, true, dgcInventory.Rows[e.RowIndex]);
                    form.ShowDialog();
                }
                else if (dgcInventory.Columns[e.ColumnIndex].Name == "Delete")
                {
                    int id = Convert.ToInt32(dgcInventory.Rows[e.RowIndex].Cells["ItemId"].Value);
                    DeleteRecord(id);
                    LoadData();
                }
            }
        }


        private void DeleteRecord(int id)
        {
            try
            {
                db.OpenConnection(conn);
                string query = "DELETE FROM Files WHERE ItemId = @id";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Record deleted successfully!", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Database Error: " + ex.Message);
            }
            finally
            {
                db.CloseConnection(conn);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgcInventory.SelectedRows.Count > 0)
            {
                // Open Files form in update mode with the selected row
                Files form = new Files(this, true, dgcInventory.SelectedRows[0]);
                form.ShowDialog();
                
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }


        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (dgcInventory.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dgcInventory.SelectedRows[0].Cells["ItemId"].Value);
                DeleteRecord(id);
                LoadData();
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchValue = txtSearch.Text.Trim();
            if (string.IsNullOrEmpty(searchValue))
            {
                MessageBox.Show("Please enter a search term.");
                return;
            }
            bool found = false;
            dgcInventory.ClearSelection();
            foreach (DataGridViewRow row in dgcInventory.Rows)
            {
                if (row.IsNewRow) continue; 
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchValue.ToLower()))
                    {
                        row.Selected = true;
                        dgcInventory.FirstDisplayedScrollingRowIndex = row.Index; 
                        found = true;
                      
                    }
                }
                if (found) break; 

            }
        }
    }
}
