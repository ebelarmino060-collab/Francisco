﻿namespace MeatShop
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Form2 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.panelControl = new System.Windows.Forms.Panel();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.btnNormal = new Guna.UI2.WinForms.Guna2Button();
            this.btnMaax = new Guna.UI2.WinForms.Guna2Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.cgpSign = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.lblError2 = new System.Windows.Forms.Label();
            this.gunabtnSignUp = new Guna.UI2.WinForms.Guna2Button();
            this.gunabtnLogin = new Guna.UI2.WinForms.Guna2Button();
            this.lblLogin = new System.Windows.Forms.Label();
            this.txtPassword = new Guna.UI2.WinForms.Guna2TextBox();
            this.txtName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblError1 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.tblsign = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblBGMP = new System.Windows.Forms.Label();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.Form2.SuspendLayout();
            this.panelControl.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.cgpSign.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Form2
            // 
            this.Form2.Controls.Add(this.panelControl);
            this.Form2.Controls.Add(this.tableLayoutPanel2);
            this.Form2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Form2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Form2.FillColor2 = System.Drawing.Color.Black;
            this.Form2.FillColor3 = System.Drawing.Color.Chocolate;
            this.Form2.FillColor4 = System.Drawing.Color.IndianRed;
            this.Form2.Location = new System.Drawing.Point(0, 0);
            this.Form2.Name = "Form2";
            this.Form2.Size = new System.Drawing.Size(1265, 631);
            this.Form2.TabIndex = 22;
            // 
            // panelControl
            // 
            this.panelControl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panelControl.BackColor = System.Drawing.Color.Transparent;
            this.panelControl.Controls.Add(this.guna2Button3);
            this.panelControl.Controls.Add(this.btnNormal);
            this.panelControl.Controls.Add(this.btnMaax);
            this.panelControl.Location = new System.Drawing.Point(1118, -7);
            this.panelControl.Name = "panelControl";
            this.panelControl.Size = new System.Drawing.Size(158, 46);
            this.panelControl.TabIndex = 21;
            // 
            // guna2Button3
            // 
            this.guna2Button3.Animated = true;
            this.guna2Button3.AnimatedGIF = true;
            this.guna2Button3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button3.BorderThickness = 1;
            this.guna2Button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button3.ForeColor = System.Drawing.Color.Black;
            this.guna2Button3.ImageSize = new System.Drawing.Size(0, 0);
            this.guna2Button3.Location = new System.Drawing.Point(108, 11);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(31, 27);
            this.guna2Button3.TabIndex = 20;
            this.guna2Button3.Text = "X";
            this.guna2Button3.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // btnNormal
            // 
            this.btnNormal.Animated = true;
            this.btnNormal.AnimatedGIF = true;
            this.btnNormal.BackColor = System.Drawing.Color.Transparent;
            this.btnNormal.BorderThickness = 1;
            this.btnNormal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNormal.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnNormal.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnNormal.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnNormal.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnNormal.FillColor = System.Drawing.Color.Transparent;
            this.btnNormal.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnNormal.ForeColor = System.Drawing.Color.Black;
            this.btnNormal.ImageSize = new System.Drawing.Size(0, 0);
            this.btnNormal.Location = new System.Drawing.Point(16, 11);
            this.btnNormal.Name = "btnNormal";
            this.btnNormal.Size = new System.Drawing.Size(31, 27);
            this.btnNormal.TabIndex = 19;
            this.btnNormal.Text = "-";
            this.btnNormal.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // btnMaax
            // 
            this.btnMaax.Animated = true;
            this.btnMaax.AnimatedGIF = true;
            this.btnMaax.BackColor = System.Drawing.Color.Transparent;
            this.btnMaax.BorderThickness = 1;
            this.btnMaax.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaax.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnMaax.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnMaax.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnMaax.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnMaax.FillColor = System.Drawing.Color.Transparent;
            this.btnMaax.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnMaax.ForeColor = System.Drawing.Color.Black;
            this.btnMaax.ImageSize = new System.Drawing.Size(0, 0);
            this.btnMaax.Location = new System.Drawing.Point(62, 11);
            this.btnMaax.Name = "btnMaax";
            this.btnMaax.Size = new System.Drawing.Size(31, 27);
            this.btnMaax.TabIndex = 18;
            this.btnMaax.Text = "+";
            this.btnMaax.Click += new System.EventHandler(this.btnMaax_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.Controls.Add(this.cgpSign, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 541F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1265, 631);
            this.tableLayoutPanel2.TabIndex = 25;
            // 
            // cgpSign
            // 
            this.cgpSign.BackColor = System.Drawing.Color.Transparent;
            this.cgpSign.BorderRadius = 20;
            this.cgpSign.BorderThickness = 20;
            this.cgpSign.Controls.Add(this.lblError2);
            this.cgpSign.Controls.Add(this.gunabtnSignUp);
            this.cgpSign.Controls.Add(this.gunabtnLogin);
            this.cgpSign.Controls.Add(this.lblLogin);
            this.cgpSign.Controls.Add(this.txtPassword);
            this.cgpSign.Controls.Add(this.txtName);
            this.cgpSign.Controls.Add(this.label2);
            this.cgpSign.Controls.Add(this.lblError1);
            this.cgpSign.Controls.Add(this.lblName);
            this.cgpSign.Controls.Add(this.tblsign);
            this.cgpSign.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.cgpSign.CustomBorderThickness = new System.Windows.Forms.Padding(5);
            this.cgpSign.Dock = System.Windows.Forms.DockStyle.Left;
            this.cgpSign.FillColor = System.Drawing.Color.Snow;
            this.cgpSign.FillColor2 = System.Drawing.Color.DimGray;
            this.cgpSign.FillColor4 = System.Drawing.Color.IndianRed;
            this.cgpSign.Location = new System.Drawing.Point(759, 45);
            this.cgpSign.Margin = new System.Windows.Forms.Padding(0);
            this.cgpSign.Name = "cgpSign";
            this.cgpSign.Size = new System.Drawing.Size(440, 541);
            this.cgpSign.TabIndex = 25;
            this.cgpSign.Paint += new System.Windows.Forms.PaintEventHandler(this.cgpSign_Paint);
            // 
            // lblError2
            // 
            this.lblError2.AutoSize = true;
            this.lblError2.BackColor = System.Drawing.Color.Transparent;
            this.lblError2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblError2.ForeColor = System.Drawing.Color.Maroon;
            this.lblError2.Location = new System.Drawing.Point(229, 287);
            this.lblError2.Name = "lblError2";
            this.lblError2.Size = new System.Drawing.Size(167, 18);
            this.lblError2.TabIndex = 13;
            this.lblError2.Text = " Password incorrect*";
            this.lblError2.Visible = false;
            // 
            // gunabtnSignUp
            // 
            this.gunabtnSignUp.Animated = true;
            this.gunabtnSignUp.AnimatedGIF = true;
            this.gunabtnSignUp.AutoRoundedCorners = true;
            this.gunabtnSignUp.BackColor = System.Drawing.Color.Transparent;
            this.gunabtnSignUp.BorderThickness = 1;
            this.gunabtnSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunabtnSignUp.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gunabtnSignUp.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gunabtnSignUp.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gunabtnSignUp.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gunabtnSignUp.FillColor = System.Drawing.Color.RosyBrown;
            this.gunabtnSignUp.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.gunabtnSignUp.ForeColor = System.Drawing.Color.Black;
            this.gunabtnSignUp.Location = new System.Drawing.Point(261, 375);
            this.gunabtnSignUp.Name = "gunabtnSignUp";
            this.gunabtnSignUp.Size = new System.Drawing.Size(132, 45);
            this.gunabtnSignUp.TabIndex = 12;
            this.gunabtnSignUp.Text = "Sign up";
            this.gunabtnSignUp.Click += new System.EventHandler(this.gunabtnSignUp_Click);
            // 
            // gunabtnLogin
            // 
            this.gunabtnLogin.Animated = true;
            this.gunabtnLogin.AnimatedGIF = true;
            this.gunabtnLogin.AutoRoundedCorners = true;
            this.gunabtnLogin.BackColor = System.Drawing.Color.Transparent;
            this.gunabtnLogin.BorderThickness = 1;
            this.gunabtnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunabtnLogin.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gunabtnLogin.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gunabtnLogin.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gunabtnLogin.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gunabtnLogin.FillColor = System.Drawing.Color.RosyBrown;
            this.gunabtnLogin.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.gunabtnLogin.ForeColor = System.Drawing.Color.Black;
            this.gunabtnLogin.Location = new System.Drawing.Point(58, 375);
            this.gunabtnLogin.Name = "gunabtnLogin";
            this.gunabtnLogin.Size = new System.Drawing.Size(132, 45);
            this.gunabtnLogin.TabIndex = 11;
            this.gunabtnLogin.Text = "Log in";
            this.gunabtnLogin.Click += new System.EventHandler(this.gunabtnLogin_Click);
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.BackColor = System.Drawing.Color.Transparent;
            this.lblLogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogin.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblLogin.Location = new System.Drawing.Point(180, 28);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(111, 37);
            this.lblLogin.TabIndex = 10;
            this.lblLogin.Text = "Log in";
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.RosyBrown;
            this.txtPassword.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.txtPassword.BorderColor = System.Drawing.Color.Black;
            this.txtPassword.BorderRadius = 5;
            this.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPassword.DefaultText = "";
            this.txtPassword.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtPassword.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtPassword.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassword.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtPassword.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtPassword.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtPassword.Location = new System.Drawing.Point(58, 245);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PlaceholderText = "";
            this.txtPassword.SelectedText = "";
            this.txtPassword.Size = new System.Drawing.Size(358, 38);
            this.txtPassword.TabIndex = 8;
            this.txtPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPassword_KeyDown);
            // 
            // txtName
            // 
            this.txtName.Animated = true;
            this.txtName.BackColor = System.Drawing.Color.RosyBrown;
            this.txtName.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.txtName.BorderColor = System.Drawing.Color.Black;
            this.txtName.BorderRadius = 5;
            this.txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtName.DefaultText = "";
            this.txtName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtName.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtName.Location = new System.Drawing.Point(58, 146);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtName.Name = "txtName";
            this.txtName.PlaceholderText = "";
            this.txtName.SelectedText = "";
            this.txtName.Size = new System.Drawing.Size(358, 38);
            this.txtName.TabIndex = 1;
            this.txtName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtName_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Password";
            // 
            // lblError1
            // 
            this.lblError1.AutoSize = true;
            this.lblError1.BackColor = System.Drawing.Color.Transparent;
            this.lblError1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblError1.ForeColor = System.Drawing.Color.Maroon;
            this.lblError1.Location = new System.Drawing.Point(184, 188);
            this.lblError1.Name = "lblError1";
            this.lblError1.Size = new System.Drawing.Size(214, 18);
            this.lblError1.TabIndex = 4;
            this.lblError1.Text = "Fill the needed information*";
            this.lblError1.Visible = false;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(36, 117);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(192, 25);
            this.lblName.TabIndex = 3;
            this.lblName.Text = "Enter Your Name";
            // 
            // tblsign
            // 
            this.tblsign.AutoScroll = true;
            this.tblsign.AutoScrollMinSize = new System.Drawing.Size(435, 531);
            this.tblsign.AutoSize = true;
            this.tblsign.BackColor = System.Drawing.Color.Transparent;
            this.tblsign.ColumnCount = 2;
            this.tblsign.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tblsign.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tblsign.Cursor = System.Windows.Forms.Cursors.Default;
            this.tblsign.Dock = System.Windows.Forms.DockStyle.Right;
            this.tblsign.Location = new System.Drawing.Point(440, 0);
            this.tblsign.MaximumSize = new System.Drawing.Size(600, 600);
            this.tblsign.Name = "tblsign";
            this.tblsign.RowCount = 4;
            this.tblsign.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tblsign.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tblsign.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tblsign.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tblsign.Size = new System.Drawing.Size(0, 541);
            this.tblsign.TabIndex = 17;
            this.tblsign.TabStop = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.lblBGMP);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(753, 535);
            this.panel2.TabIndex = 24;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // lblBGMP
            // 
            this.lblBGMP.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblBGMP.AutoSize = true;
            this.lblBGMP.BackColor = System.Drawing.Color.Transparent;
            this.lblBGMP.Font = new System.Drawing.Font("MV Boli", 40F, System.Drawing.FontStyle.Italic);
            this.lblBGMP.Location = new System.Drawing.Point(-4, 197);
            this.lblBGMP.Name = "lblBGMP";
            this.lblBGMP.Size = new System.Drawing.Size(761, 140);
            this.lblBGMP.TabIndex = 23;
            this.lblBGMP.Text = "Bureau of Jail Management \r\n   and Penology System";
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // LogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1265, 631);
            this.Controls.Add(this.Form2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LogIn";
            this.Text = "LogIn";
            this.Form2.ResumeLayout(false);
            this.panelControl.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.cgpSign.ResumeLayout(false);
            this.cgpSign.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2CustomGradientPanel Form2;
        private System.Windows.Forms.Panel panelControl;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button btnNormal;
        private Guna.UI2.WinForms.Guna2Button btnMaax;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel cgpSign;
        private System.Windows.Forms.Label lblError2;
        protected internal Guna.UI2.WinForms.Guna2Button gunabtnSignUp;
        private Guna.UI2.WinForms.Guna2Button gunabtnLogin;
        private System.Windows.Forms.Label lblLogin;
        private Guna.UI2.WinForms.Guna2TextBox txtPassword;
        private Guna.UI2.WinForms.Guna2TextBox txtName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblError1;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TableLayoutPanel tblsign;
        private System.Windows.Forms.Label lblBGMP;
    }
}