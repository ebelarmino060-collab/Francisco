﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace MeatShop
{
    public partial class LogIn: Form
    {
        Databases db = new Databases();
        public MySqlConnection conn;
        public LogIn()
        {
            InitializeComponent();
            conn = db.Connect();
        }

        private void cgpSign_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMaax_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }

        private void gunabtnSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            SignUp form = new SignUp();
            form.Show();
        }

        private void gunabtnLogin_Click(object sender, EventArgs e)
        {
            string username = txtName.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(username))
            {
                lblError1.Show();
                Visible = true;
            }
            else if (string.IsNullOrEmpty(password))
            {
                lblError2.Show(); 
                Visible = true;
            }

                try
                {
                    db.OpenConnection(conn);
                    string query = "SELECT COUNT(*) FROM LogIn WHERE UserName = @username AND Password = @password";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (count > 0)
                    {
                        MessageBox.Show("Login successful!");

                        this.Hide();
                        MainForm form = new MainForm();
                        form.Show();

                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password.");
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
        }

    

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
             
                e.SuppressKeyPress = true;           
                gunabtnLogin.Focus();

            }

        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                
                e.SuppressKeyPress = true;               
                gunabtnLogin.Focus();

            }

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
