﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Xml.Linq;

namespace MeatShop
{
    public partial class Files: Form
    {
        private MainForm parentForm;

        Databases db = new Databases();
        public MySqlConnection conn;
        public Files(MainForm form)
        {
            parentForm = form;
            InitializeComponent();
            conn = db.Connect();
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            string LastName = txtLast.Text;
            string FirstName = txtFirst.Text;
            string MiddleName = txtMiddle.Text;
            string Address = txtAddress.Text;
            string Crime = txtCrime.Text;
            int age = Convert.ToInt32(txtAge.Text);

            if (string.IsNullOrEmpty(LastName) && string.IsNullOrEmpty(FirstName) && string.IsNullOrEmpty(MiddleName) && string.IsNullOrEmpty(Address) && string.IsNullOrEmpty(Crime))
            {
                MessageBox.Show("Please fill the black.");
                return;
            }
            try
            {
                db.OpenConnection(conn);
                string query = "INSERT INTO Files (LastName, FirstName, MiddleName,Age, Address, CrimeCommit) VALUES (@lastname, @firstname, @middlename, @age, @address, @crimecommit)";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@lastname", LastName);
                    cmd.Parameters.AddWithValue("@firstname", FirstName);
                    cmd.Parameters.AddWithValue("@middlename", MiddleName);
                    cmd.Parameters.AddWithValue("@age",age );
                    cmd.Parameters.AddWithValue("@address",Address );
                    cmd.Parameters.AddWithValue("@crimecommit", Crime);
                    cmd.ExecuteNonQuery();
                }
                
                parentForm.LoadData();
              
                this.Close();
                MessageBox.Show("Item added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding item: " + ex.Message);
            }
           
        }

        private void Files_Load(object sender, EventArgs e)
        {
            
        }
        public DataTable LoadInventory()
        {
            DataTable dt = new DataTable();
            try
            {
                db.OpenConnection(conn);

                string query = "Select * from Files";

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                db.CloseConnection(conn);
            }
            return dt;
        }

        private void lblFirstName_Click(object sender, EventArgs e)
        {

        }

        private void lblMiddlename_Click(object sender, EventArgs e)
        {

        }

        private void lblAddress_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
