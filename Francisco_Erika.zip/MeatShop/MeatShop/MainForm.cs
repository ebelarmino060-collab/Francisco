﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
namespace MeatShop
{

    public partial class MainForm : Form
    {

        Databases db = new Databases();
        public MySqlConnection conn;

        public MainForm()
        {
            InitializeComponent();
            conn = db.Connect();
            LoadData();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadData();
            // Add Update button column
            DataGridViewButtonColumn updateButton = new DataGridViewButtonColumn();
            updateButton.Name = "Update";
            updateButton.Text = "Update";
            updateButton.UseColumnTextForButtonValue = true;
            dgcInventory.Columns.Add(updateButton);
            // Add Delete button column
            DataGridViewButtonColumn deleteButton = new DataGridViewButtonColumn();
            deleteButton.Name = "Delete";
            deleteButton.Text = "Delete";
            deleteButton.UseColumnTextForButtonValue = true;
            dgcInventory.Columns.Add(deleteButton);
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void btnADD_Click_1(object sender, EventArgs e)
        {
            Files form2 = new Files(this);
            form2.ShowDialog();
        }

        private void guna2GradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        public void LoadData()
        {
            try
            {

                db.OpenConnection(conn);
                string query = "SELECT * FROM Files";
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgcInventory.DataSource = dt;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void dgcInventory_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void UpdateRecord(int ItemToUpdate)
        {
            Databases db = new Databases();
            MySqlConnection conn = db.Connect();

            if(ItemToUpdate > 0)
            {
                string query = "UPDATE Files SET LastName = @lastname, FirstName = @firstname, MiddleName = @middlename WHERE ItemId = @id";
                try
                {
                    db.OpenConnection(conn);
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@lastname", ItemToUpdate);
                    cmd.Parameters.AddWithValue("@firstname", ItemToUpdate);
                    cmd.Parameters.AddWithValue("@middlename", ItemToUpdate);
                    cmd.Parameters.AddWithValue("@id", ItemToUpdate);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Update Successfully!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
               
                catch(MySqlException ex)
                {
                    MessageBox.Show("Database Error" + ex.Message);
                }
                finally
                {
                    db.CloseConnection(conn);
                }
            }
        }

        private void DeleteRecord(int id)
        {
            conn.Open();
            string query = "DELETE FROM Files WHERE id = @id";
            MySqlCommand cmd = new MySqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

    }
}
