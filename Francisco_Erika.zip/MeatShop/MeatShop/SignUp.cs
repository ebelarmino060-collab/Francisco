﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using MySql.Data.MySqlClient;

namespace MeatShop
{
    public partial class SignUp : Form
    {
        Databases db = new Databases();
        public MySqlConnection conn;

        public SignUp()
        {
            InitializeComponent();
            conn = db.Connect();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void btnMaax_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void gunabtnLogin_Click(object sender, EventArgs e)
        {

            this.Hide();
            LogIn form = new LogIn();
            form.Show();

        }

        private void gunabtnSignUp_Click(object sender, EventArgs e)
        {
            string username = txtName.Text.Trim();
            string password = txtPassword.Text.Trim();
            string confirm = txtConfirm.Text.Trim();

            if (string.IsNullOrEmpty(username))
            {
                lblError1.Show();
                Visible = true;
                return;
            }
            else if (string.IsNullOrEmpty(password))
            {
                lblError2.Show();
                Visible = true;
                return;
            }

            if (password != confirm)
            {
                lblError3.Show();
                Visible = true;
                return;
            }

            try
            {
                db.OpenConnection(conn);

                string query = "INSERT INTO LogIn (username, password) VALUES (@username, @password)";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.ExecuteNonQuery();
                }


                MessageBox.Show("Sign up successful!");

                MainForm form = new MainForm();
                form.Show();
                this.Hide();
              
            }
            catch (MySqlException ex)
            {
                if (ex.Number == 1062)
                {
                    MessageBox.Show ("Username already exists.");
                }
                else
                {
                    MessageBox.Show( "Error: " + ex.Message);
                }
            }
        }

       

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Prevent the Enter key from adding a newline 
                e.SuppressKeyPress = true;

                // Move focus to the next TextBox
                txtPassword.Focus();
                
            }

        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Prevent the Enter key from adding a newline 
                e.SuppressKeyPress = true;

                // Move focus to the next TextBox
                txtConfirm.Focus();

            }
        }

        private void txtConfirm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Prevent the Enter key from adding a newline 
                e.SuppressKeyPress = true;

                // Move focus to the next TextBox
                btnSignUps.Focus();

            }
        }

        private void txtConfirm_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
