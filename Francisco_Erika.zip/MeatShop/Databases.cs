﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MeatShop
{
   internal class Databases
   {
        private readonly string connectionString ;

        public Databases()
        {
            connectionString = "server=localhost;user=root;password=francisco123;database=BGMP;";
        }
        public  MySqlConnection Connect()
        {
            return new MySqlConnection(connectionString);
        }

        public  void OpenConnection(MySqlConnection conn)
        {
           if(conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
        }

        public  void CloseConnection(MySqlConnection conn )
        {

            if (conn.State == System.Data.ConnectionState.Open)
            {
                conn.Close();
            }
        }
    }
}
