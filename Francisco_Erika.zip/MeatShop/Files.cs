﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Xml.Linq;

namespace MeatShop
{
    public partial class Files: Form
    {
        private MainForm parentForm;

        Databases db = new Databases();
        public MySqlConnection conn;
        private bool isUpdateMode = false;
        private int selectedId = -1;

        public Files(MainForm form)
        {
            parentForm = form;
            InitializeComponent();
            conn = db.Connect();

        }
        public Files(MainForm parent, bool isUpdate, DataGridViewRow row) : this(parent)
        {
            isUpdateMode = isUpdate;
            if (isUpdate && row != null)
            {
                // Populate textboxes with data from the selected row
                txtLast.Text = row.Cells["LastName"].Value.ToString();
                txtFirst.Text = row.Cells["FirstName"].Value.ToString();
                txtMiddle.Text = row.Cells["MiddleName"].Value.ToString();
                selectedId = Convert.ToInt32(row.Cells["ItemId"].Value);
            }
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            string LastName = txtLast.Text;
            string FirstName = txtFirst.Text;
            string MiddleName = txtMiddle.Text;
            string Address = txtAddress.Text;
            string Crime = txtCrime.Text;
            int age = Convert.ToInt32(txtAge.Text);

            if (string.IsNullOrEmpty(LastName) && string.IsNullOrEmpty(FirstName) && string.IsNullOrEmpty(MiddleName) && string.IsNullOrEmpty(Address) && string.IsNullOrEmpty(Crime))
            {
                MessageBox.Show("Please fill the black.");
                return;
            }
            try
            {
                db.OpenConnection(conn);
                string query = "INSERT INTO Files (LastName, FirstName, MiddleName,Age, Address, CrimeCommit) VALUES (@lastname, @firstname, @middlename, @age, @address, @crimecommit)";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@lastname", LastName);
                    cmd.Parameters.AddWithValue("@firstname", FirstName);
                    cmd.Parameters.AddWithValue("@middlename", MiddleName);
                    cmd.Parameters.AddWithValue("@age",age );
                    cmd.Parameters.AddWithValue("@address",Address );
                    cmd.Parameters.AddWithValue("@crimecommit", Crime);
                    cmd.ExecuteNonQuery();
                }
                
                parentForm.LoadData();
              
                this.Close();
                MessageBox.Show("Item added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding item: " + ex.Message);
            }
           
        }
       

        private void Files_Load(object sender, EventArgs e)
        {
            
        }
        public DataTable LoadInventory()
        {
            DataTable dt = new DataTable();
            try
            {
                db.OpenConnection(conn);

                string query = "Select * from Files";

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                db.CloseConnection(conn);
            }
            return dt;
        }

        private void UpdateRecord(int id, string last, string first, string middle)
        {
           
            
                string query = "UPDATE Files SET LastName = @lastname, FirstName = @firstname, MiddleName = @middlename WHERE ItemId = @id";
                try
                {
                    db.OpenConnection(conn);
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@lastname", last);
                    cmd.Parameters.AddWithValue("@firstname", first);
                    cmd.Parameters.AddWithValue("@middlename", middle);
                    cmd.Parameters.AddWithValue("@id", id);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Update Successfully!", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                catch (MySqlException ex)
                {
                    MessageBox.Show("Database Error" + ex.Message);
                }
                finally
                {
                    db.CloseConnection(conn);
                }


            
        }


        private void lblFirstName_Click(object sender, EventArgs e)
        {

        }

        private void lblMiddlename_Click(object sender, EventArgs e)
        {

        }

        private void lblAddress_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (isUpdateMode && selectedId != -1)
            {
               
                UpdateRecord(selectedId, txtLast.Text, txtFirst.Text, txtMiddle.Text);
                parentForm.LoadData();
                
                this.Close();

            }

          
        }

        private void txtLast_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                e.SuppressKeyPress = true;
                txtFirst.Focus();

            }
        }

        private void txtFirst_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                e.SuppressKeyPress = true;
                txtMiddle.Focus();

            }
        }

        private void txtMiddle_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMiddle_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                e.SuppressKeyPress = true;
                txtAddress.Focus();

            }
        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAddress_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                e.SuppressKeyPress = true;
                txtCrime.Focus();

            }
        }

        private void txtCrime_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                e.SuppressKeyPress = true;
                txtAge.Focus();

            }
        }

        private void txtAge_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                e.SuppressKeyPress = true;
                btnADD.Focus();

            }
        }
    }
}
